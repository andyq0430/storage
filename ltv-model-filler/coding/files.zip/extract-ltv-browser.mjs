// extract-ltv-browser.mjs —— VV总控系统数据提取（Browser Tool 版 v7.3）
// 注意：浏览器驱动由外部 browser 工具执行；本模块提供：
//   ① 注入到页面 evaluate() 的 DOM 提取函数（纯函数、可序列化）
//   ② 提取计划（步骤序列）生成器
//   ③ 把两表抓取结果落盘为 raw_data.json 的合并函数

import fs from 'node:fs';

// ---------- ① DOM 提取函数（在浏览器 evaluate 中运行） ----------
// 这些函数体会被 .toString() 注入页面，故内部不得引用模块作用域变量。

/** 提取 .el-table 索引1：新增用户数 & LTV */
export function extractLtvTable() {
  const tables = document.querySelectorAll('.el-table');
  const t = tables[1]; // 索引1
  if (!t) return [];
  const head = [...t.querySelectorAll('.el-table__header th')].map((th) =>
    th.innerText.trim()
  );
  const colOf = (kw) => head.findIndex((h) => h.includes(kw));
  const idx = {
    date: colOf('日期'),
    newUsers: colOf('新增'),
    ltv1: colOf('1日'), ltv3: colOf('3日'), ltv7: colOf('7日'),
    ltv15: colOf('15日'), ltv30: colOf('30日'), ltv60: colOf('60日'),
  };
  const cell = (cells, i) => (i >= 0 && cells[i] ? cells[i].innerText.trim() : '');
  return [...t.querySelectorAll('.el-table__body tbody tr')].map((tr) => {
    const c = tr.querySelectorAll('td');
    return {
      date: cell(c, idx.date),
      newUsers: cell(c, idx.newUsers),
      ltv1: cell(c, idx.ltv1), ltv3: cell(c, idx.ltv3), ltv7: cell(c, idx.ltv7),
      ltv15: cell(c, idx.ltv15), ltv30: cell(c, idx.ltv30), ltv60: cell(c, idx.ltv60),
    };
  });
}

/** 提取 .el-table 索引2：付费率 & 付费金额 */
export function extractQualityTable() {
  const tables = document.querySelectorAll('.el-table');
  const t = tables[2]; // 索引2
  if (!t) return [];
  const head = [...t.querySelectorAll('.el-table__header th')].map((th) =>
    th.innerText.trim()
  );
  const colOf = (kw) => head.findIndex((h) => h.includes(kw));
  const idx = {
    date: colOf('日期'),
    payRateD0: head.findIndex((h) => h.includes('付费率') && h.includes('D0')),
    payD0: head.findIndex((h) => h.includes('付费') && h.includes('D0') && !h.includes('率')),
    payD7: head.findIndex((h) => h.includes('付费') && h.includes('D7')),
  };
  const cell = (cells, i) => (i >= 0 && cells[i] ? cells[i].innerText.trim() : '');
  return [...t.querySelectorAll('.el-table__body tbody tr')].map((tr) => {
    const c = tr.querySelectorAll('td');
    return {
      date: cell(c, idx.date),
      payRateD0: cell(c, idx.payRateD0),
      payD0: cell(c, idx.payD0),
      payD7: cell(c, idx.payD7),
    };
  });
}

// ---------- ② 提取计划生成器 ----------
/**
 * 生成给 browser 工具按序执行的步骤计划。
 * @param {object} cfg { url, platform, secondaryPassword }
 */
export function buildExtractionPlan(cfg = {}) {
  const {
    url = 'https://vv-admin.example.com',
    platform = 'vv',
    secondaryPassword = null,
  } = cfg;
  const steps = [
    { action: 'launch', desc: '启动浏览器（复用用户Chrome登录态）' },
    { action: 'navigate', target: url, desc: '导航到VV总控管理系统' },
  ];
  if (secondaryPassword) {
    steps.push({
      action: 'type',
      selector: 'input[type="password"]',
      value: secondaryPassword,
      desc: '输入二级密码',
    });
    steps.push({ action: 'click', selector: '.confirm-btn,button[type="submit"]', desc: '确认二级密码' });
  }
  steps.push(
    { action: 'click', text: 'vv', desc: '点击vv按钮，选择平台' },
    { action: 'click', text: '新增', desc: '切换到「新增」标签' },
    { action: 'waitFor', selector: '.el-table', desc: '等待表格渲染' },
    {
      action: 'evaluate',
      fn: extractLtvTable.toString(),
      saveAs: 'ltvTable',
      desc: '提取渠道LTV表格（.el-table[1]）',
    },
    {
      action: 'evaluate',
      fn: extractQualityTable.toString(),
      saveAs: 'qualityTable',
      desc: '提取用户质量表格（.el-table[2]）',
    },
    { action: 'close', desc: '关闭浏览器' }
  );
  return { platform, url, createdAt: new Date().toISOString(), steps };
}

// ---------- ③ 结果落盘 ----------
/** 把 browser 工具 evaluate 得到的两张表合并写入 raw_data.json */
export function saveRawData({ platform = 'vv', ltvTable = [], qualityTable = [] }, outPath = 'raw_data.json') {
  const raw = { platform, extractedAt: new Date().toISOString(), ltvTable, qualityTable };
  fs.writeFileSync(outPath, JSON.stringify(raw, null, 2), 'utf8');
  console.log(`✅ extract: LTV ${ltvTable.length} 行 / 质量 ${qualityTable.length} 行 → ${outPath}`);
  return raw;
}

// ---- CLI：仅打印提取计划 ----
if (import.meta.url === `file://${process.argv[1]}`) {
  const plan = buildExtractionPlan({ platform: process.argv[2] || 'vv' });
  fs.writeFileSync('extraction_plan.json', JSON.stringify(plan, null, 2));
  console.log('📋 提取计划已生成 → extraction_plan.json');
  console.log(`   共 ${plan.steps.length} 步，请用 browser 工具按序执行 evaluate 步骤。`);
}
