// fill-model.mjs —— 把建模数据填充进《游戏LTV经营模型.xlsx》
// 依赖：exceljs（运行环境需已安装：npm i exceljs）
// 行为：模板存在→在「数据」/「明细」sheet 写入；不存在→新建工作簿。

import fs from 'node:fs';
import path from 'node:path';

const LTV_DAYS = [1, 3, 7, 15, 30, 60];
const HEADERS = [
  '日期', '新增用户数',
  ...LTV_DAYS.map((d) => `${d}日LTV`),
  '付费率D0', '付费D0', '付费D7',
];

function rowToArray(r) {
  return [
    r.date, r.newUsers,
    ...LTV_DAYS.map((d) => r[`ltv${d}`] ?? 0),
    r.payRateD0 ?? 0, r.payD0 ?? 0, r.payD7 ?? 0,
  ];
}

/**
 * 填充模型。
 * @param {object} input transform() 的输出 {meta, rows}
 * @param {object} opts {template, out, sheetName}
 */
export async function fillModel(input, opts = {}) {
  const {
    template = '游戏LTV经营模型.xlsx',
    out = '游戏LTV经营模型.xlsx',
    sheetName = '数据',
  } = opts;

  const ExcelJS = (await import('exceljs')).default;
  const wb = new ExcelJS.Workbook();

  if (fs.existsSync(template)) {
    await wb.xlsx.readFile(template);
  } else {
    console.warn(`⚠ 模板 ${template} 不存在，新建工作簿`);
  }

  let ws = wb.getWorksheet(sheetName);
  if (ws) {
    // 清空旧数据（保留第一行表头），从第2行重写
    const last = ws.rowCount;
    for (let i = last; i >= 2; i--) ws.spliceRows(i, 1);
    if (ws.getRow(1).getCell(1).value == null) ws.getRow(1).values = HEADERS;
  } else {
    ws = wb.addWorksheet(sheetName);
    ws.addRow(HEADERS);
  }

  // 表头样式
  const head = ws.getRow(1);
  head.font = { bold: true, color: { argb: 'FFFFFFFF' } };
  head.eachCell((c) => {
    c.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF2E5AAC' } };
    c.alignment = { horizontal: 'center' };
  });

  // 写入明细
  for (const r of input.rows) {
    const row = ws.addRow(rowToArray(r));
    // 百分比列格式化
    row.getCell(HEADERS.indexOf('付费率D0') + 1).numFmt = '0.00%';
  }

  // 写元数据 sheet
  let metaWs = wb.getWorksheet('元数据') || wb.addWorksheet('元数据');
  metaWs.spliceRows(1, metaWs.rowCount);
  metaWs.addRows([
    ['渠道', input.meta.channel],
    ['平台', input.meta.platform],
    ['数据区间', `${input.meta.dateRange.start} ~ ${input.meta.dateRange.end}`],
    ['批次数', input.meta.batchCount],
    ['生成时间', input.meta.generatedAt],
  ]);

  await wb.xlsx.writeFile(out);
  console.log(`✅ fill-model: ${input.rows.length} 行 → ${path.resolve(out)}`);
  return out;
}

/** 文件版：读 input_data.json → 写 xlsx */
export async function fillModelFile(dataFile = 'input_data.json', opts) {
  const input = JSON.parse(fs.readFileSync(dataFile, 'utf8'));
  return fillModel(input, opts);
}

// ---- CLI ----
if (import.meta.url === `file://${process.argv[1]}`) {
  const args = process.argv.slice(2);
  const dfIdx = args.indexOf('--data-file');
  const dataFile = dfIdx >= 0 ? args[dfIdx + 1] : 'input_data.json';
  fillModelFile(dataFile).catch((e) => {
    console.error('❌ fill-model 失败:', e.message);
    process.exit(1);
  });
}
