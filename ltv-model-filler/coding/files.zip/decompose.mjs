// decompose.mjs —— LTV/营收 三因子 LMDI-I 分解
// 模型：总营收 V = N(新增用户) × p(付费率) × a(人均付费/ARPPU)
// LMDI-I 加法分解：ΔV = ΔV_N + ΔV_p + ΔV_a
// 每个因子贡献： ΔV_x = L(V_t, V_0) · ln(x_t / x_0)
// 对数平均 L(a,b) = (a - b) / (ln a - ln b)，a==b 时取 a。

/** 对数平均 (logarithmic mean) */
export function logMean(a, b) {
  if (a <= 0 || b <= 0) return 0;        // 防止 log 域错误
  if (Math.abs(a - b) < 1e-12) return a; // 极限情形
  return (a - b) / (Math.log(a) - Math.log(b));
}

/**
 * 把一行明细换算成三因子。
 * @param {object} row { newUsers, payRateD0, payD7 }
 * @returns {{N:number,p:number,a:number,V:number}}
 *   N=新增用户, p=付费率, a=人均付费(ARPPU=付费D7/付费率), V=总营收
 */
export function toFactors(row) {
  const N = Number(row.newUsers) || 0;
  const p = Number(row.payRateD0) || 0;
  const payPerNewUser = Number(row.payD7) || 0; // 付费D7：每新增用户7日付费额
  // ARPPU = 每新增用户付费额 / 付费率 = 每付费用户付费额
  const a = p > 0 ? payPerNewUser / p : 0;
  const V = N * p * a; // = N × payPerNewUser，即总营收
  return { N, p, a, V };
}

/**
 * 对两期（基线 base → 当期 curr）做 LMDI-I 三因子分解。
 * @returns 分解结果（绝对贡献 + 百分比贡献）
 */
export function lmdiDecompose(baseRow, currRow) {
  const b = toFactors(baseRow);
  const c = toFactors(currRow);
  const dV = c.V - b.V;

  const Lv = logMean(c.V, b.V);
  const safeLn = (x0, xt) => (x0 > 0 && xt > 0 ? Math.log(xt / x0) : 0);

  const contribN = Lv * safeLn(b.N, c.N);
  const contribP = Lv * safeLn(b.p, c.p);
  const contribA = Lv * safeLn(b.a, c.a);

  const residual = dV - (contribN + contribP + contribA); // LMDI-I 理论上≈0
  const pct = (x) => (Math.abs(dV) > 1e-9 ? (x / dV) * 100 : 0);

  return {
    base: b,
    curr: c,
    totalChange: dV,
    factors: {
      newUsers: { absolute: contribN, percent: pct(contribN), label: '规模(新增用户)' },
      payRate: { absolute: contribP, percent: pct(contribP), label: '付费率' },
      arppu: { absolute: contribA, percent: pct(contribA), label: '客单价(ARPPU)' },
    },
    residual,
    // 瀑布图坐标：base → +N → +p → +a → curr
    waterfall: buildWaterfall(b.V, [
      ['规模', contribN],
      ['付费率', contribP],
      ['客单价', contribA],
    ], c.V),
  };
}

/** 生成瀑布图所需的累计区间 [{name, start, end, delta, type}] */
export function buildWaterfall(startVal, steps, endVal) {
  const bars = [{ name: '基线', start: 0, end: startVal, delta: startVal, type: 'total' }];
  let cursor = startVal;
  for (const [name, delta] of steps) {
    bars.push({
      name,
      start: Math.min(cursor, cursor + delta),
      end: Math.max(cursor, cursor + delta),
      delta,
      type: delta >= 0 ? 'increase' : 'decrease',
    });
    cursor += delta;
  }
  bars.push({ name: '当期', start: 0, end: endVal, delta: endVal, type: 'total' });
  return bars;
}

/**
 * 对一组按日期排序的明细，取首行为基线、末行为当期做分解。
 * @param {Array} rows 已按日期升序排序的合并明细
 */
export function decomposeWindow(rows) {
  if (!rows || rows.length < 2) {
    throw new Error('分解至少需要两期数据（基线 + 当期）');
  }
  const base = rows[0];
  const curr = rows[rows.length - 1];
  const result = lmdiDecompose(base, curr);
  result.baseDate = base.date;
  result.currDate = curr.date;
  return result;
}

// ---- CLI ----
if (import.meta.url === `file://${process.argv[1]}`) {
  const demoBase = { date: 'D0', newUsers: 1000, payRateD0: 0.03, payD7: 0.9 };
  const demoCurr = { date: 'D6', newUsers: 1400, payRateD0: 0.028, payD7: 1.1 };
  console.log(JSON.stringify(lmdiDecompose(demoBase, demoCurr), null, 2));
}
