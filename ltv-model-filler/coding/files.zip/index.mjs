// index.mjs —— ltv-model-filler 流水线编排（可执行函数集）
// 把 SKILL.md 描述的执行流程封装成可组合调用的函数。
//
// 用法（编程式）：
//   import { runPipeline, transform, fillModel, genReport } from './index.mjs';
//   await runPipeline({ rawData, days: 7 });
//
// 用法（命令行）：
//   node index.mjs full        # transform → fill → report（读 raw_data.json）
//   node index.mjs plan        # 仅生成浏览器提取计划
//   node index.mjs report      # 仅生成 HTML（读 input_data.json）

import fs from 'node:fs';
import { buildExtractionPlan, saveRawData } from './scripts/extract-ltv-browser.mjs';
import { transform, transformFile } from './scripts/transform-data.mjs';
import { fillModel, fillModelFile } from './scripts/fill-model.mjs';
import { buildReportHtml, genReportFile } from './scripts/gen-report.mjs';
import { decomposeWindow } from './scripts/decompose.mjs';

export { buildExtractionPlan, saveRawData, transform, fillModel, buildReportHtml, decomposeWindow };

/**
 * 全流程（数据已抓取后）：raw → transform → Excel + HTML。
 * @param {object} o
 *   o.rawData   已抓取的 {platform,ltvTable,qualityTable}（与 rawPath 二选一）
 *   o.rawPath   raw_data.json 路径（默认）
 *   o.days      近 N 日窗口（默认7）
 *   o.excel     是否生成 Excel（默认 true，需 exceljs）
 *   o.outDir    输出目录（默认当前目录）
 */
export async function runPipeline(o = {}) {
  const { days = 7, excel = true, outDir = '.', rawPath = 'raw_data.json' } = o;
  const raw = o.rawData ?? JSON.parse(fs.readFileSync(rawPath, 'utf8'));

  // ① 转换 + 近7日
  const input = transform(raw, { days });
  const inputPath = `${outDir}/input_data.json`;
  fs.writeFileSync(inputPath, JSON.stringify(input, null, 2), 'utf8');
  console.log(`✅ transform: ${input.rows.length} 批次 (${input.meta.dateRange.start}~${input.meta.dateRange.end})`);

  // ② 分解（供日志/校验）
  const decomp = decomposeWindow(input.rows);
  console.log(`📊 营收变动 ${decomp.totalChange >= 0 ? '+' : ''}${Math.round(decomp.totalChange)} | ` +
    `规模 ${decomp.factors.newUsers.percent.toFixed(1)}% / 付费率 ${decomp.factors.payRate.percent.toFixed(1)}% / ARPPU ${decomp.factors.arppu.percent.toFixed(1)}%`);

  // ③ Excel
  let xlsxPath = null;
  if (excel) {
    try {
      xlsxPath = await fillModel(input, { out: `${outDir}/游戏LTV经营模型.xlsx` });
    } catch (e) {
      console.warn(`⚠ Excel 跳过（${e.message}）。如需生成请先 npm i exceljs`);
    }
  }

  // ④ HTML
  const htmlPath = `${outDir}/report.html`;
  fs.writeFileSync(htmlPath, buildReportHtml(input), 'utf8');
  console.log(`✅ gen-report → ${htmlPath}`);

  return { input, decomp, paths: { input: inputPath, xlsx: xlsxPath, html: htmlPath } };
}

// ---- CLI ----
if (import.meta.url === `file://${process.argv[1]}`) {
  const cmd = process.argv[2] || 'full';
  if (cmd === 'plan') {
    const plan = buildExtractionPlan({ platform: process.argv[3] || 'vv' });
    fs.writeFileSync('extraction_plan.json', JSON.stringify(plan, null, 2));
    console.log(`📋 提取计划 (${plan.steps.length} 步) → extraction_plan.json`);
  } else if (cmd === 'transform') {
    transformFile();
  } else if (cmd === 'fill') {
    await fillModelFile();
  } else if (cmd === 'report') {
    genReportFile();
  } else {
    await runPipeline().catch((e) => { console.error('❌', e.message); process.exit(1); });
  }
}
