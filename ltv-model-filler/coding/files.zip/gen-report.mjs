// gen-report.mjs —— 生成自包含可视化 HTML 报告（5个标签页）
// 标签页：数据概览 / LTV分解 / 诊断→行动 / 6周甘特图 / KPI看板
// 无外部依赖，内联 CSS + 原生 JS + SVG。

import fs from 'node:fs';
import { decomposeWindow } from './decompose.mjs';

const fmtInt = (n) => Math.round(n).toLocaleString('zh-CN');
const fmtPct = (n) => `${(n * 100).toFixed(2)}%`;
const fmt2 = (n) => Number(n).toFixed(2);
const sign = (n) => (n >= 0 ? '+' : '');

// ---------- 诊断引擎：分解信号 → 运营动作 ----------
export function diagnose(decomp) {
  const f = decomp.factors;
  const out = [];
  const big = Math.abs(decomp.totalChange) > 1e-6;

  if (f.payRate.absolute < 0 && Math.abs(f.payRate.percent) > 15) {
    out.push({
      level: 'warn',
      signal: `付费率拖累营收 ${fmt2(f.payRate.absolute)}（${fmt2(f.payRate.percent)}%）`,
      action: '排查近期投放人群质量与新手付费引导漏斗，优先修复 D0 付费转化',
    });
  }
  if (f.newUsers.absolute > 0 && f.payRate.absolute < 0) {
    out.push({
      level: 'warn',
      signal: '增长靠堆量、转化在掉',
      action: '增量用户在稀释付费率：收紧低质量量级，把预算挪向高 ROI 渠道',
    });
  }
  if (f.arppu.absolute > 0 && Math.abs(f.arppu.percent) > 30) {
    out.push({
      level: 'good',
      signal: `客单价(ARPPU)正向贡献 ${fmt2(f.arppu.percent)}%`,
      action: '客单价提升有效：固化当前付费点/档位设计，复制到同类渠道',
    });
  }
  if (f.newUsers.absolute > 0 && Math.abs(f.newUsers.percent) > 50) {
    out.push({
      level: 'good',
      signal: `规模是主增长引擎（${fmt2(f.newUsers.percent)}%）`,
      action: '规模红利期：在 CAC 可控前提下加大优质量级，同步监控付费率不被稀释',
    });
  }
  if (!out.length && big) {
    out.push({ level: 'info', signal: '三因子贡献相对均衡', action: '维持现状，按周跟踪各因子边际变化' });
  }
  if (!big) out.push({ level: 'info', signal: '营收基本持平', action: '关注结构变化而非总量，逐因子盯防' });
  return out;
}

// ---------- 6周甘特 ----------
function buildGantt(diags) {
  const phases = [
    { name: '诊断对齐：拉通投放/产品/数据口径', week: [1, 1] },
    { name: '付费漏斗修复（D0引导/档位）', week: [1, 3] },
    { name: '量级结构优化（渠道ROI再分配）', week: [2, 4] },
    { name: '客单价实验（付费点A/B）', week: [3, 5] },
    { name: '效果复盘 & KPI对标', week: [5, 6] },
  ];
  return phases;
}

// ---------- KPI 看板基线 ----------
function buildKpi(rows, decomp) {
  const last = rows[rows.length - 1];
  return [
    { name: '新增用户数', base: fmtInt(decomp.base.N), curr: fmtInt(decomp.curr.N), target: fmtInt(decomp.curr.N * 1.1) },
    { name: '付费率D0', base: fmtPct(decomp.base.p), curr: fmtPct(decomp.curr.p), target: fmtPct(Math.max(decomp.base.p, decomp.curr.p) * 1.05) },
    { name: 'ARPPU', base: fmt2(decomp.base.a), curr: fmt2(decomp.curr.a), target: fmt2(decomp.curr.a * 1.05) },
    { name: '7日LTV', base: fmt2(rows[0].ltv7 ?? 0), curr: fmt2(last.ltv7 ?? 0), target: fmt2((last.ltv7 ?? 0) * 1.08) },
  ];
}

// ---------- SVG 瀑布图 ----------
function waterfallSvg(bars) {
  const W = 760, H = 320, pad = 50;
  const max = Math.max(...bars.map((b) => b.end)) * 1.1 || 1;
  const bw = (W - pad * 2) / bars.length - 16;
  const y = (v) => H - pad - (v / max) * (H - pad * 2);
  const color = { total: '#2E5AAC', increase: '#2BA672', decrease: '#D9534F' };
  let svg = `<svg viewBox="0 0 ${W} ${H}" width="100%">`;
  svg += `<line x1="${pad}" y1="${H - pad}" x2="${W - pad}" y2="${H - pad}" stroke="#ccc"/>`;
  bars.forEach((b, i) => {
    const x = pad + i * ((W - pad * 2) / bars.length) + 8;
    const top = y(b.end), bot = y(b.start);
    svg += `<rect x="${x}" y="${top}" width="${bw}" height="${Math.max(2, bot - top)}" fill="${color[b.type]}" rx="3"/>`;
    svg += `<text x="${x + bw / 2}" y="${top - 6}" font-size="11" text-anchor="middle" fill="#333">${b.type === 'total' ? fmtInt(b.end) : sign(b.delta) + fmtInt(b.delta)}</text>`;
    svg += `<text x="${x + bw / 2}" y="${H - pad + 16}" font-size="11" text-anchor="middle" fill="#666">${b.name}</text>`;
  });
  return svg + '</svg>';
}

// ---------- 甘特 SVG ----------
function ganttSvg(phases) {
  const W = 760, rowH = 34, pad = 12, labelW = 280, weeks = 6;
  const H = phases.length * rowH + 40;
  const colW = (W - labelW - pad) / weeks;
  let svg = `<svg viewBox="0 0 ${W} ${H}" width="100%">`;
  for (let w = 0; w < weeks; w++) {
    const x = labelW + w * colW;
    svg += `<text x="${x + colW / 2}" y="20" font-size="11" text-anchor="middle" fill="#888">W${w + 1}</text>`;
    svg += `<line x1="${x}" y1="28" x2="${x}" y2="${H - 8}" stroke="#eee"/>`;
  }
  phases.forEach((p, i) => {
    const y = 34 + i * rowH;
    svg += `<text x="0" y="${y + 14}" font-size="12" fill="#333">${p.name}</text>`;
    const x = labelW + (p.week[0] - 1) * colW;
    const wpx = (p.week[1] - p.week[0] + 1) * colW - 6;
    svg += `<rect x="${x}" y="${y}" width="${wpx}" height="20" rx="5" fill="#2E5AAC" opacity="0.85"/>`;
  });
  return svg + '</svg>';
}

// ---------- 主生成函数 ----------
export function buildReportHtml(input) {
  const rows = input.rows;
  const decomp = decomposeWindow(rows);
  const diags = diagnose(decomp);
  const gantt = buildGantt(diags);
  const kpi = buildKpi(rows, decomp);

  const overviewRows = rows.map((r) => `<tr>
    <td>${r.date}</td><td>${fmtInt(r.newUsers)}</td><td>${fmt2(r.ltv7 ?? 0)}</td>
    <td>${fmt2(r.ltv30 ?? 0)}</td><td>${fmtPct(r.payRateD0 ?? 0)}</td><td>${fmt2(r.payD7 ?? 0)}</td>
  </tr>`).join('');

  const factorRows = Object.values(decomp.factors).map((f) => `<tr>
    <td>${f.label}</td><td class="${f.absolute >= 0 ? 'pos' : 'neg'}">${sign(f.absolute)}${fmtInt(f.absolute)}</td>
    <td class="${f.absolute >= 0 ? 'pos' : 'neg'}">${sign(f.percent)}${fmt2(f.percent)}%</td>
  </tr>`).join('');

  const diagRows = diags.map((d) => `<div class="diag ${d.level}">
    <div class="sig">▸ ${d.signal}</div><div class="act">${d.action}</div></div>`).join('');

  const kpiRows = kpi.map((k) => `<tr><td>${k.name}</td><td>${k.base}</td><td>${k.curr}</td><td>${k.target}</td></tr>`).join('');

  return `<!doctype html><html lang="zh"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>VV渠道LTV经营报告</title>
<style>
:root{--blue:#2E5AAC;--bg:#f5f7fb;--card:#fff;--line:#e6ebf3}
*{box-sizing:border-box}body{margin:0;font-family:-apple-system,"Segoe UI","Microsoft YaHei",sans-serif;background:var(--bg);color:#1f2937}
header{background:var(--blue);color:#fff;padding:22px 28px}
header h1{margin:0;font-size:20px}header .sub{opacity:.85;font-size:13px;margin-top:4px}
.tabs{display:flex;gap:4px;background:#fff;padding:0 16px;border-bottom:1px solid var(--line);overflow-x:auto}
.tab{padding:14px 18px;cursor:pointer;border-bottom:3px solid transparent;white-space:nowrap;font-size:14px;color:#6b7280}
.tab.active{color:var(--blue);border-color:var(--blue);font-weight:600}
.panel{display:none;padding:24px 28px}.panel.active{display:block}
.card{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:20px;margin-bottom:18px}
.kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:14px}
.kpi{background:#fff;border:1px solid var(--line);border-radius:12px;padding:16px}
.kpi .v{font-size:24px;font-weight:700;color:var(--blue)}.kpi .l{font-size:12px;color:#6b7280;margin-top:4px}
table{width:100%;border-collapse:collapse;font-size:13px}th,td{padding:9px 10px;text-align:right;border-bottom:1px solid var(--line)}
th:first-child,td:first-child{text-align:left}th{background:#f0f4fb;color:#374151}
.pos{color:#2BA672}.neg{color:#D9534F}
.diag{border-left:4px solid #9ca3af;background:#fafbfc;padding:12px 14px;border-radius:0 8px 8px 0;margin-bottom:10px}
.diag.warn{border-color:#D9534F;background:#fdf3f2}.diag.good{border-color:#2BA672;background:#f1f9f5}.diag.info{border-color:var(--blue);background:#f0f4fb}
.diag .sig{font-weight:600;margin-bottom:4px}.diag .act{font-size:13px;color:#4b5563}
h3{margin:0 0 14px;font-size:15px;color:#111827}
</style></head><body>
<header><h1>VV渠道 LTV 经营诊断报告</h1>
<div class="sub">平台 ${input.meta.platform} · 区间 ${input.meta.dateRange.start} ~ ${input.meta.dateRange.end} · ${input.meta.batchCount} 批次 · 生成于 ${new Date(input.meta.generatedAt).toLocaleString('zh-CN')}</div></header>
<div class="tabs">
  <div class="tab active" data-t="0">数据概览</div>
  <div class="tab" data-t="1">LTV分解</div>
  <div class="tab" data-t="2">诊断→行动</div>
  <div class="tab" data-t="3">6周甘特图</div>
  <div class="tab" data-t="4">KPI看板</div>
</div>

<div class="panel active">
  <div class="kpis">
    <div class="kpi"><div class="v">${fmtInt(decomp.curr.N)}</div><div class="l">当期新增用户</div></div>
    <div class="kpi"><div class="v">${fmtPct(decomp.curr.p)}</div><div class="l">付费率D0</div></div>
    <div class="kpi"><div class="v">${fmt2(decomp.curr.a)}</div><div class="l">ARPPU</div></div>
    <div class="kpi"><div class="v ${decomp.totalChange>=0?'pos':'neg'}">${sign(decomp.totalChange)}${fmtInt(decomp.totalChange)}</div><div class="l">营收变动(基线→当期)</div></div>
  </div>
  <div class="card"><h3>逐批次明细</h3><table>
    <tr><th>日期</th><th>新增</th><th>7日LTV</th><th>30日LTV</th><th>付费率D0</th><th>付费D7</th></tr>
    ${overviewRows}</table></div>
</div>

<div class="panel">
  <div class="card"><h3>三因子瀑布图（基线 ${decomp.baseDate} → 当期 ${decomp.currDate}）</h3>${waterfallSvg(decomp.waterfall)}</div>
  <div class="card"><h3>贡献分析</h3><table>
    <tr><th>因子</th><th>绝对贡献</th><th>占比</th></tr>${factorRows}</table>
    <p style="font-size:12px;color:#9ca3af">残差 ${fmt2(decomp.residual)}（LMDI-I 完全分解，残差应≈0）</p></div>
</div>

<div class="panel"><div class="card"><h3>诊断结论 → 运营动作</h3>${diagRows}</div></div>

<div class="panel"><div class="card"><h3>6周实施排期</h3>${ganttSvg(gantt)}</div></div>

<div class="panel"><div class="card"><h3>KPI 看板（基线 / 当期 / 目标）</h3><table>
  <tr><th>指标</th><th>基线</th><th>当期</th><th>目标</th></tr>${kpiRows}</table></div></div>

<script>
document.querySelectorAll('.tab').forEach(function(t){t.onclick=function(){
  var i=+t.dataset.t;
  document.querySelectorAll('.tab').forEach(function(x){x.classList.remove('active')});
  document.querySelectorAll('.panel').forEach(function(p){p.classList.remove('active')});
  t.classList.add('active');document.querySelectorAll('.panel')[i].classList.add('active');
}});
</script></body></html>`;
}

/** 文件版 */
export function genReportFile(dataFile = 'input_data.json', outPath = 'report.html') {
  const input = JSON.parse(fs.readFileSync(dataFile, 'utf8'));
  const html = buildReportHtml(input);
  fs.writeFileSync(outPath, html, 'utf8');
  console.log(`✅ gen-report → ${outPath}`);
  return outPath;
}

// ---- CLI ----
if (import.meta.url === `file://${process.argv[1]}`) {
  const [df = 'input_data.json', out = 'report.html'] = process.argv.slice(2);
  genReportFile(df, out);
}
