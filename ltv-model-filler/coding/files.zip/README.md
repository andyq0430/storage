# ltv-model-filler （可执行函数版 v7.3）

把原 `SKILL.md` 文档描述的流程改写为**可 import / 可命令行执行**的函数模块。

## 文件结构

```
ltv-model-filler/
├── index.mjs                      # 编排入口（runPipeline 等）
├── package.json
└── scripts/
    ├── extract-ltv-browser.mjs    # 浏览器提取：DOM evaluate 函数 + 提取计划生成器
    ├── transform-data.mjs         # 合并两表 + 近7日过滤 + 字段清洗
    ├── decompose.mjs              # LMDI-I 三因子分解（规模/付费率/ARPPU）
    ├── fill-model.mjs             # exceljs 填充《游戏LTV经营模型.xlsx》
    └── gen-report.mjs             # 自包含 HTML 报告（5标签页 + 诊断引擎）
```

## 核心导出函数

| 模块 | 函数 | 作用 |
|---|---|---|
| extract-ltv-browser | `buildExtractionPlan(cfg)` | 生成给 browser 工具执行的步骤计划 |
| | `extractLtvTable()` / `extractQualityTable()` | 注入页面 `evaluate()` 的 DOM 提取函数 |
| | `saveRawData(data)` | 抓取结果落盘 `raw_data.json` |
| transform-data | `transform(raw,{days})` | 合并 + 近 N 日过滤 → 建模输入 |
| | `filterRecentDays(rows,days)` | 自动识别最新日期向前推 N 天 |
| decompose | `lmdiDecompose(base,curr)` | 两期 LMDI-I 三因子加法分解 |
| | `decomposeWindow(rows)` | 取首行=基线、末行=当期 |
| fill-model | `fillModel(input,opts)` | 填充 Excel（异步，需 exceljs） |
| gen-report | `buildReportHtml(input)` | 返回完整 HTML 字符串 |
| | `diagnose(decomp)` | 分解信号 → 运营动作 |
| index | `runPipeline({rawData,days})` | 全流程一键执行 |

## 用法

### 编程式
```js
import { runPipeline } from './index.mjs';
const { decomp, paths } = await runPipeline({ rawPath: 'raw_data.json', days: 7 });
```

### 命令行
```bash
node index.mjs plan        # ① 生成浏览器提取计划 → extraction_plan.json
#   用 browser 工具按 plan.steps 执行 evaluate，结果存 raw_data.json
node index.mjs full        # ② raw → transform → Excel + HTML 全流程
# 或分步：
node index.mjs transform   # raw_data.json → input_data.json（近7日）
node index.mjs fill        # input_data.json → 游戏LTV经营模型.xlsx
node index.mjs report      # input_data.json → report.html
```

## 三因子模型

`总营收 V = N(新增) × p(付费率) × a(ARPPU)`，其中 `a = 付费D7 / 付费率`。
LMDI-I 加法分解：`ΔV = ΔV_N + ΔV_p + ΔV_a`，每因子贡献 `= L(V_t,V_0)·ln(x_t/x_0)`，
对数平均 `L(a,b)=(a-b)/(ln a-ln b)`。完全分解，残差≈0。

## 依赖
- Node ≥ 18（ESM）
- `exceljs`（仅 Excel 填充需要：`npm i exceljs`；缺失时 HTML 仍正常生成）
- browser 工具（仅数据抓取阶段）
