// transform-data.mjs —— 原始抓取数据 → 建模输入数据
// 职责：① 合并 LTV 表 + 用户质量表（按日期）；② 自动识别最新日期并保留近7日；
//       ③ 标准化字段、补全元数据。对应 SKILL v7.2「自动提取近7日数据」。

import fs from 'node:fs';

const LTV_DAYS = [1, 3, 7, 15, 30, 60];

/** 解析 YYYY-MM-DD / YYYY/MM/DD → Date（UTC，避免时区漂移） */
export function parseDate(s) {
  if (!s) return null;
  const m = String(s).match(/(\d{4})\D(\d{1,2})\D(\d{1,2})/);
  if (!m) return null;
  return new Date(Date.UTC(+m[1], +m[2] - 1, +m[3]));
}

/** Date → YYYY-MM-DD */
export function fmtDate(d) {
  return d.toISOString().slice(0, 10);
}

/**
 * 合并两张表为按日期的明细数组。
 * @param {Array} ltvTable  [{date,newUsers,ltv1,ltv3,ltv7,ltv15,ltv30,ltv60}]
 * @param {Array} qualityTable [{date,payRateD0,payD0,payD7}]
 */
export function mergeByDate(ltvTable = [], qualityTable = []) {
  const map = new Map();
  const ensure = (date) => {
    if (!map.has(date)) map.set(date, { date });
    return map.get(date);
  };

  for (const r of ltvTable) {
    if (!r.date) continue;
    const row = ensure(r.date);
    row.newUsers = num(r.newUsers);
    for (const d of LTV_DAYS) row[`ltv${d}`] = num(r[`ltv${d}`]);
  }
  for (const r of qualityTable) {
    if (!r.date) continue;
    const row = ensure(r.date);
    row.payRateD0 = num(r.payRateD0);
    row.payD0 = num(r.payD0);
    row.payD7 = num(r.payD7);
  }
  // 升序排序
  return [...map.values()].sort(
    (a, b) => parseDate(a.date) - parseDate(b.date)
  );
}

/** 数值清洗：去掉 %、千分位逗号、空格 */
export function num(v) {
  if (v == null || v === '') return 0;
  if (typeof v === 'number') return v;
  let s = String(v).trim().replace(/,/g, '');
  const isPct = s.endsWith('%');
  s = s.replace('%', '');
  const n = parseFloat(s);
  if (Number.isNaN(n)) return 0;
  return isPct ? n / 100 : n;
}

/**
 * 保留「最新日期往前推 N 天」的窗口（默认7天，含最新日）。
 * @returns {{rows:Array, range:{start:string,end:string,days:number}}}
 */
export function filterRecentDays(rows, days = 7) {
  if (!rows.length) return { rows: [], range: { start: null, end: null, days } };
  const latest = rows.reduce(
    (mx, r) => (parseDate(r.date) > mx ? parseDate(r.date) : mx),
    parseDate(rows[0].date)
  );
  const cutoff = new Date(latest);
  cutoff.setUTCDate(cutoff.getUTCDate() - (days - 1)); // 含当日 → -(N-1)
  const kept = rows.filter((r) => {
    const d = parseDate(r.date);
    return d && d >= cutoff && d <= latest;
  });
  return {
    rows: kept,
    range: { start: fmtDate(cutoff), end: fmtDate(latest), days },
  };
}

/**
 * 主转换函数：raw_data.json 结构 → input_data.json 结构。
 * @param {object} raw {platform, ltvTable, qualityTable}
 * @param {object} opts {days=7}
 */
export function transform(raw, { days = 7 } = {}) {
  const merged = mergeByDate(raw.ltvTable, raw.qualityTable);
  const { rows, range } = filterRecentDays(merged, days);
  return {
    meta: {
      platform: raw.platform || 'vv',
      channel: 'VV',
      generatedAt: new Date().toISOString(),
      dateRange: range,
      batchCount: rows.length,
    },
    rows,
  };
}

/** 文件版：读 raw → 写 input */
export function transformFile(rawPath = 'raw_data.json', outPath = 'input_data.json', opts) {
  const raw = JSON.parse(fs.readFileSync(rawPath, 'utf8'));
  const out = transform(raw, opts);
  fs.writeFileSync(outPath, JSON.stringify(out, null, 2), 'utf8');
  console.log(`✅ transform: ${out.rows.length} 批次 | 区间 ${out.meta.dateRange.start} ~ ${out.meta.dateRange.end} → ${outPath}`);
  return out;
}

// ---- CLI ----
if (import.meta.url === `file://${process.argv[1]}`) {
  const [rawPath = 'raw_data.json', outPath = 'input_data.json'] = process.argv.slice(2);
  transformFile(rawPath, outPath);
}
